public interface Shape3D {
    double getSurfaceArea();
}