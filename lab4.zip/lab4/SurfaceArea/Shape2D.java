public interface Shape2D {
    double getArea();
    String getName();
}