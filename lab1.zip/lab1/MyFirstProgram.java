public class MyFirstProgram {
    public static void main(String[] args) {
        System.out.println("Hello! This is my first program.");
        System.out.println("Bye Bye!");
    }
}
